import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import VisxExample from "../components/VisxExample";

describe("VisxExample", () => {
  it("renders chart title", () => {
    render(<VisxExample />);
    expect(screen.getByText(/visx Example/i)).toBeInTheDocument();
  });
});